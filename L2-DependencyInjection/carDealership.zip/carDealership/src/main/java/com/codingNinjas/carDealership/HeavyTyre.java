package com.codingNinjas.carDealership;

public class HeavyTyre implements Tyre {

	@Override
	public String getTyreInfo() {
		return " with heavy tyre";
	}

}
