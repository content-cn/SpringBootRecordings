package com.codingNinjas.carDealership;

public class SportsTyre implements Tyre{

	@Override
	public String getTyreInfo() {
		return " with Sports Tyres";
	}

}
