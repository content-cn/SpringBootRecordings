package com.codingNinjas.carDealership;

public interface Tyre {
	public String getTyreInfo();
}
